"""Render locally frozen seeds, without changing their dataset records."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HELPERS = Path(__file__).resolve().parents[1]
if str(HELPERS) not in sys.path:
    sys.path.insert(0, str(HELPERS))
from render_variants import ROOT, RENDER_LOCK, assert_baseline, load_question, pixel_hash


def main():
    parser = argparse.ArgumentParser(description="Verify deterministic original-image redraws for this dataset.")
    parser.add_argument("--output-dir", type=Path, help="Separate redraw directory; defaults to reproduced/originals")
    args = parser.parse_args()
    destination = args.output_dir.resolve() if args.output_dir else ROOT / "reproduced/originals"
    if destination.is_relative_to(ROOT) and not destination.is_relative_to(ROOT / "reproduced"):
        raise ValueError("Original redraws cannot overwrite accepted dataset inputs.")
    if destination.is_relative_to(ROOT.parent / "construct_dataset"):
        raise ValueError("Original redraws cannot overwrite the source dataset.")
    destination.mkdir(parents=True, exist_ok=True)
    with RENDER_LOCK:
        assert_baseline()
        records = [json.loads(line) for line in (ROOT / "dataset.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        for index, record in enumerate(records, 1):
            _, question, _ = load_question(record["id"])
            image = destination / f"{record['id']}.png"
            question.draw(index, output_path=image)
            if pixel_hash(image) != pixel_hash(ROOT / record["image"]):
                raise ValueError(f"Original redraw mismatch: {record['id']}")
            print(f"{record['id']}: original pixels match")


if __name__ == "__main__":
    main()
