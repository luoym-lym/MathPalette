# 二次收集数据

制作 C 变体：双击本目录 `start_special_workbench.cmd`，打开 http://127.0.0.1:8767 ，选择题目后打开画板。可添加红点、辅助虚线、修改原曲线颜色/线型，Ctrl 吸附整数格点。人工 Pass 后保存到本目录 `special_variant/`，包含图片、插件、recipes 和重绘函数。支持继续与 agent 协作，详见 `../fine_grained_special_workbench/README.md`。备份和移动时将数据集与 `fine_grained_special_workbench` 一起保留。

本批包含四道已冻结原题和对应人工通过的 A/B 变体，使用新的独立编号：

| 题号 | 题目内容 | 答案 |
| --- | --- | --- |
| Ana01 | x 趋于 1 时的左极限 | `0` |
| Ana02 | 比较 f(1) 与 f(-1) | `"B"` |
| Ana03 | 从三次函数图确定二次项系数 b | `-1` |
| Ana04 | 比较 y1、y2 的周期 | `"B"` |

每题有一张原图、5 张 A 图片和 5 张 B 图片；合计 **4 道题、44 张图片**。本批未收集 C 变体。

## 数据入口

- `dataset.jsonl`：四字段原题记录；题干和答案保持来源内容及类型。
- `image/`：按新题号命名的四张原图，文件字节与来源图片相同。
- `base_variant/AnaXX/`：10 张已审核图片、完整 `recipes.json`、10 个重绘函数。
- `dataset_generator/`：本批公共绘图协议、固定题目类、独立 A/B 回放器和 baseline manifest。
- `verification/collection_report.json`：原图与全部 A/B 的像素重绘验证结果。
- `protocol.md`：后续整理规范。

A/B 参数、采样 seed、candidate_id、实际 created_at/reviewed_at 和审核状态沿用已有审核记录。recipes 中的题号、图片路径和基线均对应本目录的独立数据。

本批执行器版本为 `fine-grained-AB-1.0.0`。它回放已经审核的冻结参数，使用本目录的四道题和公共渲染器。删除原数据集后，本目录仍可独立读取与重绘。

## 重绘

从 Research 目录执行，默认输出到本数据集的 `reproduced/`，保留正式图片：

```powershell
# 重绘四张原图并核对像素
python -B MathPalette/fine_grained_dataset/dataset_generator/dataset_generator/generate_dataset.py

# 按该题的冻结 recipe 重绘一个 A/B 槽位
python -B MathPalette/fine_grained_dataset/base_variant/Ana01/draw_variants.py A01
python -B MathPalette/fine_grained_dataset/base_variant/Ana01/draw_variants.py B03
```

也可以调用各题 `draw_variants.py` 中的 `draw_A01(output_path=None)`～`draw_B05(output_path=None)`，或使用共享入口：

```powershell
python -B MathPalette/fine_grained_dataset/dataset_generator/render_variants.py Ana02 B01 --output C:/Temp/Ana02_B01.png
```

重绘前校验本批输入指纹、依赖版本和参数哈希，重绘后核对解码像素；不一致则停止。命令支持从其他工作目录以绝对入口路径执行。正式原题文件、正式 A/B 图片及旧 `construct_dataset` 不作为验证输出目录。

源实例的 `draw(num=0, output_path=None)` 同时支持原来的 num 参数和单独的输出位置。原题数目与类定位取自本批清单，不硬编码 80 题。

## 后续收集

本批原图和 A/B 已冻结，C 将按后续人工方案重新收集。新题使用后续稳定编号；沿用 `protocol.md` 的字段和目录约定，并真实记录来源。

本批 baseline manifest 绑定当前原题清单、四个题目类、公共渲染器、协议、依赖清单、回放器和原图。后续追加种子或调整这些输入时，需要明确更新批次基线，并验证已有冻结参数仍能重绘出相同像素；不能只改文件而继续冒用旧指纹。旧工作台默认配置仍指向旧数据集，接入新的 A/B/C 工作台时需另配新数据根目录与独立运行状态。
